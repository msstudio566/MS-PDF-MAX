plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mspdfmax.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mspdfmax.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
