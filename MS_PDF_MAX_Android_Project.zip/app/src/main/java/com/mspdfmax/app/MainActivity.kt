package com.mspdfmax.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val red = Color.rgb(190, 25, 45)
    private var selectedPdf: Uri? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        buildHome()
    }

    private fun buildHome() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 248, 250))
            setPadding(24, 28, 24, 24)
        }

        val title = TextView(this).apply {
            text = "MS PDF MAX"
            textSize = 30f
            setTextColor(red)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your documents. Your control."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 24)
        }
        page.addView(title)
        page.addView(subtitle)

        addAction(page, "Open PDF", "Choose a PDF file to work with") { openPdf() }
        addAction(page, "Crop PDF", "Set a crop area for every page in the selected PDF") { cropPdf() }
        addAction(page, "Merge PDFs", "Combine two PDF files into one") {
            Toast.makeText(this, "Merge tool is planned for the next build.", Toast.LENGTH_LONG).show()
        }
        addAction(page, "Split PDF", "Save a selected page range as a new PDF") {
            Toast.makeText(this, "Split tool is planned for the next build.", Toast.LENGTH_LONG).show()
        }
        addAction(page, "Sign / Annotate", "Signature and annotation tools are planned") {
            Toast.makeText(this, "Signature tools are planned for the next build.", Toast.LENGTH_LONG).show()
        }

        status = TextView(this).apply {
            text = "No PDF selected"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(4, 18, 4, 4)
        }
        page.addView(status)

        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun addAction(parent: LinearLayout, label: String, detail: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.WHITE)
            elevation = 3f
        }
        val button = Button(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            isAllCaps = false
            setOnClickListener { action() }
        }
        val desc = TextView(this).apply {
            text = detail
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(4, 6, 4, 0)
        }
        card.addView(button)
        card.addView(desc)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 14 }
        parent.addView(card, params)
    }

    private fun openPdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, REQUEST_OPEN)
    }

    @Deprecated("Using legacy activity result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OPEN && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedPdf = uri
            status.text = "Selected: ${uri.lastPathSegment ?: "PDF file"}"
            Toast.makeText(this, "PDF selected. Tap Crop PDF to continue.", Toast.LENGTH_SHORT).show()
        } else if (requestCode == REQUEST_SAVE && resultCode == RESULT_OK) {
            val dest = data?.data ?: return
            val source = pendingOutput ?: return
            try {
                contentResolver.openOutputStream(dest)?.use { out ->
                    source.inputStream().use { input -> input.copyTo(out) }
                }
                status.text = "Saved: ${dest.lastPathSegment ?: "cropped.pdf"}"
                Toast.makeText(this, "Cropped PDF saved.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not save file: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private var pendingOutput: File? = null

    private fun cropPdf() {
        val uri = selectedPdf
        if (uri == null) {
            Toast.makeText(this, "First tap Open PDF and choose a file.", Toast.LENGTH_LONG).show()
            return
        }

        // Starter implementation: applies a centered crop box to each page.
        // A visual drag-to-select crop interface will be added in a later iteration.
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open PDF")
            val document = input.use { PDDocument.load(it) }
            for (page in document.pages) {
                val box = page.mediaBox
                val marginX = box.width * 0.05f
                val marginY = box.height * 0.05f
                page.cropBox = com.tom_roush.pdfbox.pdmodel.common.PDRectangle(
                    box.lowerLeftX + marginX,
                    box.lowerLeftY + marginY,
                    box.width - 2 * marginX,
                    box.height - 2 * marginY
                )
            }
            val outFile = File(cacheDir, "ms_pdf_max_cropped_${System.currentTimeMillis()}.pdf")
            FileOutputStream(outFile).use { document.save(it) }
            document.close()
            pendingOutput = outFile
            val saveIntent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                putExtra(Intent.EXTRA_TITLE, "MS_PDF_MAX_Cropped.pdf")
            }
            startActivityForResult(saveIntent, REQUEST_SAVE)
        } catch (e: Exception) {
            Toast.makeText(this, "Crop failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val REQUEST_OPEN = 100
        private const val REQUEST_SAVE = 101
    }
}
