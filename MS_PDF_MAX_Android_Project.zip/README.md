# MS PDF MAX — Android starter project

This is a starter Android Studio project for the MS PDF MAX app.

## Current working functionality
- Original red-and-white home screen
- Android document picker to select a PDF
- Crop PDF action that applies a centered 5% crop margin to each page and lets the user save a new PDF

## Not yet implemented
- Visual drag-to-select crop box
- PDF rendering/reader screen
- Merge and split tools
- Signature, annotation, OCR, compression, and conversion
- Automated tests and release signing

## Build
1. Open this folder in Android Studio (on a computer), or upload the project to a trusted online Android build environment.
2. Allow Gradle to sync and download dependencies.
3. Build > Build APK(s).
4. Test the APK with sample PDFs before sharing or publishing it.

Package ID: `com.mspdfmax.app`

Minimum Android: API 26 (Android 8.0). Compile/target SDK: 35.

Important: This is source code, not a prebuilt APK. It has not been compiled or device-tested in this environment. Review and test before real-world use.
